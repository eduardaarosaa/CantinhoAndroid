package com.app.sample.recipe.Conexao;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;

public class Sessao {

    private Activity nActivity;
    private SharedPreferences Pre;


    public Sessao(Activity activity) {

    nActivity = activity;

    Pre = activity.getSharedPreferences("Sessao", Context.MODE_PRIVATE);

    }

  private  String idsessao = "idsessao";

    public  void setidsessao(String id){

        SharedPreferences.Editor set = Pre.edit();

        set.putString(idsessao, id);

        set.commit();

    }

    public String getIdsessao(){

        return Pre.getString(idsessao,"");
    }

    private  String logado = "logado";

    public  void setlogado(){

        SharedPreferences.Editor set = Pre.edit();

        set.putBoolean(logado, true);

        set.commit();

    }

    public  void setdeslogado(){

        SharedPreferences.Editor set = Pre.edit();

        set.putBoolean(logado, false);

        set.commit();

    }


    public Boolean getLogado(){

        return Pre.getBoolean(logado,false);
    }

}
